
library(pacman)
p_load(tidyverse,ggridges,tidyfst,showtext,patchwork,magick)


read_csv("CAS-Fellow-2001-2021.csv") %>% 
  transmute(name = ����,age = ����,ins = ������λ,
            subject = רҵ,year = as.factor(���),field = ѧ��)-> cas

cas


  
theme_cas = function(base_size = 12){
  require(showtext)
  font_add(family = "kaiti",regular = "STKAITI.TTF")
  font_add(family = "times",regular = "times.ttf")
  showtext_auto()
  
  half_line <- base_size/2
  theme(
    plot.title = element_text(size = base_size * 1.8, hjust = 0, vjust = 1, family = "kaiti",
                              face = "bold", margin = margin(b = half_line * 1.2)), 
    plot.caption = element_text(size = rel(0.9), family = "kaiti",
                                hjust = 1, vjust = 1, margin = margin(t = half_line * 0.9)),
    plot.background = element_rect(fill = "skyblue",color = "transparent"),
    panel.background = element_rect(fill = "transparent",color = "black"), 
    axis.ticks = element_blank(),
    panel.grid.major = element_blank(), 
    panel.grid.minor = element_blank(),
    axis.title = element_text(family = "kaiti",size = base_size * 1.3,face = "bold"),
    axis.text = element_text(family = "times",size = base_size * 1.1),
    axis.title.x = element_text(margin = margin(t = 20)),
    axis.title.y = element_text(margin = margin(r = 20),angle = 90),
    legend.title = element_text(family = "kaiti",size = base_size * 1.1),
    legend.text = element_text(family = "times",size = base_size),
    legend.background = element_rect(fill = "transparent",color = "transparent")
  )
}

theme_set(theme_cas())

yearly_age =  cas %>% 
  mutate_dt(median = median(age),no = .N,by = year) %>% 
  mutate(median_all = median(age)) %>% 
  ggplot(aes(year,age)) +
  geom_violin(aes(fill = no),color = "transparent", trim = F) +
  geom_boxplot(width = .1) +
  stat_summary(fun=median, size = 2,
               geom="point", color="red") +
  geom_hline(aes(yintercept = median(cas$age)),
             linetype = "dashed",color = "blue") +
  scale_fill_distiller(palette = "YlGn",direction = 1,name = "��ѡ����") +
  theme(legend.position = c(.75,.9),legend.direction="horizontal") +
  labs(y = "��ѡ����",x = "�������")

field_age = cas %>% 
  mutate_dt(median_age = median(age),by = field) %>% 
  mutate(field = reorder(field,median_age)) %>% 
  ggplot(aes(x = age,y = field))+
  geom_density_ridges(aes(fill = field),
                      # color = "transparent",
                      # linetype = "dashed",
                      quantile_lines = TRUE, quantiles = 2,
                      show.legend = F,alpha = .75) +
  geom_label(aes(x = median_age + 2, label = formatC(median_age, digits = 1, format = "f")),
             family = "times",vjust = -2.5) +
  labs(y = NULL,x = "��ѡ����") +
  expand_limits(y = 7) +
  scale_fill_manual(values = c(
    "#FF3200",
    "#E9E4A6",
    "#0076BB",
    "#E9A17C",
    "#1BB6AF",
    "#172869"
  )) +
  theme(axis.text.y = element_text(family = "kaiti")) 

"cas.jpg" %>% 
  image_read() %>% 
  image_ggplot(interpolate = T) -> cas_logo

yearly_age + field_age +
  plot_annotation(
    title = "�й���ѧԺԺʿ����ֲ�",
    caption=("
    ע����ͼ�к��Ϊ����Ժʿ��ѡ������λ������ɫ����Ϊ2001-2011��Ժʿ��ѡ������λ����56������ͼ�б�־����Ϊ�������λ��
                  ����Ԫ ���� | ������Դ���й���ѧԺ|���ӣ�http://casad.cas.cn/")) +
  plot_layout(widths = c(.6,.4))

ggsave(filename = "cas_age.png",dpi = 100,width = 10)


